import React from "react";

const Home = () => {
    return(
        <h1>
            Hello
        </h1>
    )
}

export default Home;